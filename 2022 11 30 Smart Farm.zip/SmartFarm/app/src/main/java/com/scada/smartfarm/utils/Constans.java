package com.scada.smartfarm.utils;

import android.net.Uri;

public class Constans {
    public static final int PERMISSION_CODE_READ_GALLERY = 1;
    public static final int PERMISSION_CODE_OPEN_CAMERA = 2;

    public final static String urlDomain = "http://45.64.99.254:5000/";
//    public final static String urlDomain = "http://192.168.5.214:5000/";


}
