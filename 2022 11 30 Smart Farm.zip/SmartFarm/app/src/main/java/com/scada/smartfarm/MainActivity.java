package com.scada.smartfarm;

import static com.scada.smartfarm.utils.Constans.PERMISSION_CODE_OPEN_CAMERA;
import static com.scada.smartfarm.utils.Constans.PERMISSION_CODE_READ_GALLERY;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.scada.smartfarm.api.APIClient;
import com.scada.smartfarm.api.APIInterface;
import com.scada.smartfarm.databinding.ActivityMainBinding;
import com.scada.smartfarm.response.BoxesDataItem;
import com.scada.smartfarm.response.ResponseFarms;
import com.scada.smartfarm.response.Temperature;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding activityMainBinding;
    private Dialog dialog;
    private Uri image_uri;
    private String mImageFileLocation = "";
    private String raplace = "";
    protected ArrayList<ResponseFarms> list;
    protected ArrayList<Integer> listAbsoultePost,listAbsoultePost2;
    protected ArrayList<Double> listrelativPost;
    protected ArrayList<Double> listBeans;
    protected ArrayList<Double> listHist;

    APIInterface apiInterface;
    Bitmap bitmap;
    Bitmap rotateBitmap;
    int minVal, maxVal;

    String min, max;
    Integer abs;
    Double abs1, binsItem, hinsItem;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityMainBinding = ActivityMainBinding.inflate(getLayoutInflater());
        View view = activityMainBinding.getRoot();

        list = new ArrayList<>();
        listAbsoultePost = new ArrayList<>();
        listAbsoultePost2 = new ArrayList<>();
        listrelativPost = new ArrayList<Double>();
        listHist = new ArrayList<Double>();
        listBeans = new ArrayList<Double>();

        setContentView(view);
        try {
            this.getSupportActionBar().hide();
        } catch (NullPointerException e) {
        }
        setContentView(view);

        dialog = new Dialog(MainActivity.this);


        activityMainBinding.ivAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                min = activityMainBinding.minInput.getText().toString();
                max = activityMainBinding.maxInput.getText().toString();
//                if (min.matches("") && max.matches("")) {
//                    Toast.makeText(MainActivity.this, "Isi angka dulu", Toast.LENGTH_SHORT).show();
//                    return;
//
//                }else{
//
//                }
                selectImage();

            }
        });

    }

    private void selectImage() {
        dialog.setTitle("Image");
        dialog.setContentView(R.layout.dialog_custom_design);
        TextView gallery = dialog.findViewById(R.id.gallery);
        gallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    // Permission is not granted
                    if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                        // Show an explanation to the user *asynchronously* -- don't block
                        // this thread waiting for the user's response! After the user
                        // sees the explanation, try again to request the permission.
                    } else {
                        // No explanation needed; request the permission
                        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSION_CODE_READ_GALLERY);
                    }
                } else {
                    //permission already granted
                    Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(intent, 2);
                    dialog.hide();

                }
            }
        });

        TextView cammera2 = dialog.findViewById(R.id.cammera2);
        cammera2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_DENIED || checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
                        String[] permision = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE};
                        requestPermissions(permision, PERMISSION_CODE_OPEN_CAMERA);
                    } else {
                        //permission already granted
                        openCamera();
                    }
                } else {
                    // system OS < Marshmallow
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    File f = new File(android.os.Environment.getExternalStorageDirectory(), "temp.jpg");
                    intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(f));
                    openCamera();
                }
            }
        });

        dialog.show();
    }

    private void openCamera() {
        dialog.hide();

        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, "New Picture");
        values.put(MediaStore.Images.Media.DESCRIPTION, "From the Camera");
        //image_uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        //camera intent
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        File photoFile = null;
        try {
            photoFile = createImageFile();
        } catch (IOException e) {
            e.printStackTrace();
        }

        image_uri = FileProvider.getUriForFile(this, this.getApplicationContext().getPackageName() + ".provider", photoFile);
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, image_uri);

        startActivityForResult(cameraIntent, 1);
    }

    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "IMAGE_" + timeStamp + "_";
        boolean isEmulated = Environment.isExternalStorageEmulated();

        //File storageDirectory = getFilesDir();
        File storageDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        //File storageDirectory = Environment.getDataDirectory();

        File image = File.createTempFile(imageFileName, ".jpg", storageDirectory);
        mImageFileLocation = image.getAbsolutePath();

        return image;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 1: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permission was granted, do something you want
                } else {
                    // permission denied
                    Toast.makeText(MainActivity.this, "Permission denied to read your External storage", Toast.LENGTH_SHORT).show();
                }
                return;
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == 1) {

                try {
                    Bitmap bitmap;
                    BitmapFactory.Options bitmapOptions = new BitmapFactory.Options();
                    bitmap = BitmapFactory.decodeFile(mImageFileLocation, bitmapOptions);

                    rotateImage(setReducedImageSize());

                } catch (Exception e) {
                    e.printStackTrace();
                }


            } else if (requestCode == 2) {
                Uri selectedImage = data.getData();
                String[] filePath = {MediaStore.Images.Media.DATA};
                Cursor c = getContentResolver().query(selectedImage, filePath, null, null, null);
                c.moveToFirst();
                int columnIndex = c.getColumnIndex(filePath[0]);
                String picturePath = c.getString(columnIndex);
                mImageFileLocation = picturePath;

                c.close();
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inSampleSize = 4; // InSampleSize = 4;

                try {
                    InputStream inputStream = getContentResolver().openInputStream(data.getData());
                    bitmap = BitmapFactory.decodeStream(inputStream);

                    activityMainBinding.viewImage.setImageBitmap(bitmap);
                    activityMainBinding.btnAnalyze.setEnabled(true);

//                    if (min.matches("") && max.matches("")) {
//                        activityMainBinding.btnAnalyze.setEnabled(false);
//                        Toast.makeText(this, "ANGKA MINIMAL/ MAKSIMAL KOSONG, SILAHKAN ISI LALU UPLOAD GAMBAR KEMBALI", Toast.LENGTH_SHORT).show();
//                        return;
//                    }else{

                    activityMainBinding.btnAnalyze.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
//                                minVal = Integer.parseInt(activityMainBinding.minInput.getText().toString());
//                                maxVal = Integer.parseInt(activityMainBinding.maxInput.getText().toString());
//                                min = String.valueOf(minVal);
//                                max = String.valueOf(maxVal);
                            min = activityMainBinding.minInput.getText().toString();
                            max = activityMainBinding.maxInput.getText().toString();

                            if (min.matches("") && max.toString().matches("")) {
                                Toast.makeText(getApplicationContext(), "ANGKA MINIMAL/ MAKSIMAL KOSONG, SILAHKAN ISI LALU UPLOAD GAMBAR KEMBALI", Toast.LENGTH_SHORT).show();
//                                activityMainBinding.btnAnalyze.setEnabled(false);
                                return;
                            } else {
                                uploadImage(bitmap, activityMainBinding.minInput.getText().toString(), activityMainBinding.maxInput.getText().toString());


                            }

                        }
                    });


                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void rotateImage(Bitmap bitmap) {
        ExifInterface exifInterface = null;
        try {
            exifInterface = new ExifInterface(mImageFileLocation);
        } catch (IOException e) {
            e.printStackTrace();
        }
        int orientation = exifInterface.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_UNDEFINED);
        Matrix matrix = new Matrix();
        switch (orientation) {
            case ExifInterface.ORIENTATION_ROTATE_90:
                matrix.setRotate(90);
                break;
            case ExifInterface.ORIENTATION_ROTATE_180:
                matrix.setRotate(180);
                break;
            default:
        }
        rotateBitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);


        activityMainBinding.viewImage.setImageBitmap(rotateBitmap);


        if (activityMainBinding.minInput.getText().toString().matches("") && activityMainBinding.maxInput.toString().matches("")) {
            Toast.makeText(this, "ANGKA MINIMAL/ MAKSIMAL KOSONG, SILAHKAN ISI LALU UPLOAD GAMBAR KEMBALI", Toast.LENGTH_SHORT).show();
            return;
        } else {
            minVal = Integer.parseInt(activityMainBinding.minInput.getText().toString());
            maxVal = Integer.parseInt(activityMainBinding.maxInput.getText().toString());
//
//                        min = String.valueOf(minVal);
//                        max = String.valueOf(maxVal);

            activityMainBinding.btnAnalyze.setVisibility(View.VISIBLE);

            activityMainBinding.btnAnalyze.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    min = String.valueOf(minVal);
                    max = String.valueOf(maxVal);
                    uploadImage(rotateBitmap, min, max);

                }
            });
        }


    }

    private Bitmap setReducedImageSize() {
        int targetImageViewWidth = activityMainBinding.viewImage.getWidth();
        int targetImageViewHeight = activityMainBinding.viewImage.getHeight();

        BitmapFactory.Options bmOptions = new BitmapFactory.Options();
        bmOptions.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(mImageFileLocation, bmOptions);
        int cameraImageWidth = bmOptions.outWidth;
        int cameraImageHeight = bmOptions.outHeight;

        int scaleFactor = Math.min(cameraImageWidth / targetImageViewWidth, cameraImageHeight / targetImageViewHeight);
        bmOptions.inSampleSize = scaleFactor;
        bmOptions.inJustDecodeBounds = false;

        //Bitmap photoReducedSizeBitmap = BitmapFactory.decodeFile(mImageFileLocation, bmOptions);
        //mPhotoCapturedImageView.setImageBitmap(photoReducedSizeBitmap);
        Bitmap compressedOri = BitmapFactory.decodeFile(mImageFileLocation, bmOptions);

        Bitmap compressed = null;
        //save bitmap to byte array

        try {
            File file = new File(mImageFileLocation);
            FileOutputStream fOut = new FileOutputStream(file);
            compressedOri.compress(Bitmap.CompressFormat.JPEG, 85, fOut);
            fOut.flush();
            fOut.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return compressedOri;
    }

    private void uploadImage(Bitmap rotateBitmap, String min, String max) {
        final ProgressDialog pd = new ProgressDialog(this);
        pd.setMessage("Uploading Image...");
        pd.setCancelable(false);
        pd.show();

        File file = new File(mImageFileLocation);
        int file_size = Integer.parseInt(String.valueOf(file.length() / 1024));

        apiInterface = APIClient.getClient().create(APIInterface.class);
//        RequestBody requestBody = RequestBody.create(MediaType.parse("image/*"), file);
//        MultipartBody.Part parts = MultipartBody.Part.createFormData("image", file.getName(), requestBody);

        RequestBody requestFile = RequestBody.create(MediaType.parse("image/*"), file);
        MultipartBody.Part bodyPaarts = MultipartBody.Part.createFormData("image", file.getName(), requestFile);

        RequestBody someData = RequestBody.create(MediaType.parse("text/plain"), "This is a new Image");

        RequestBody req2 = RequestBody.create(MediaType.parse("text/plain"), min);
        RequestBody req3 = RequestBody.create(MediaType.parse("text/plain"), max);

        Call<ResponseFarms> call = apiInterface.callResponseFarm(bodyPaarts, req2, req3);
        call.enqueue(new Callback<ResponseFarms>() {
            @Override
            public void onResponse(Call<ResponseFarms> call, Response<ResponseFarms> response) {
//                Log.e("response",new Gson().toJson(response.body()));
                if (response.code() == 200) {
//                    Log.d("responsez suc",""+response);
                    ResponseFarms responseFarms = response.body();
                    List<BoxesDataItem> boxData = responseFarms.getBoxData().getBoxesData();
                    int boxDataSize = responseFarms.getBoxData().getBoxesData().size();

                    for (int i = 0; i < boxDataSize; i++) {
                        if (i >= 0 && i < boxDataSize) {

                            List<Integer> absolutPath = boxData.get(i).getAbsolutePosition();
                            List<Double> relativPost = boxData.get(i).getRelativePosition();

                            // Temp
                            Temperature temp = boxData.get(i).getTemperature();



                            for (int j = 0; j < absolutPath.size(); j++) {
                                abs = absolutPath.get(j);
//                                Log.d("",""+abs);
                                listAbsoultePost.add(abs);
                            }
                            listAbsoultePost2 =  listAbsoultePost;

                            for (int j = 0; j < relativPost.size(); j++) {
                                abs1 = relativPost.get(j);
//                                Log.d("",""+abs);
                                listrelativPost.add(abs1);
                            }

                            List<Double> hist = temp.getHist();
                            for (int k = 0; k < hist.size(); k++) {
                                hinsItem = hist.get(k);
                                listHist.add(hinsItem);
                            }

                            List<Double> binns = temp.getBins();
                            for (int l = 0; l < binns.size(); l++) {
                                binsItem = binns.get(l);
                                listBeans.add(binsItem);
                            }
                        }
                    }

                    String gson = new Gson().toJson(responseFarms);
                    raplace = gson;
                    Log.d("",""+listAbsoultePost);
                    String showStrinRespons =  "\tbox_data : [{ '\"'\n\tAbsolute Position\'" +listAbsoultePost2 +"'\'\n\tRelative Position\""+listrelativPost+"\n\tTemperature: {'\"\n\tBins'\" "+listBeans+" '\"\n\tHist \'" +listHist;
                    raplace.replaceAll("image","");
                    activityMainBinding.resutlApi.setText(""+showStrinRespons);
                    list.add(responseFarms);

//                    for (int i = 0; i< count; i++){
//                        if (i>=0 && i<count){
//                        }
//                    }

                    Toast.makeText(getApplicationContext(), "Berhaasil", Toast.LENGTH_LONG).show();
                    pd.hide();
                } else {
//                    Log.d("responsez not suc", "" + response);
                    Toast.makeText(getApplicationContext(), "Gagal, angka tidak bisa kosong", Toast.LENGTH_LONG).show();
                    pd.hide();

                }
            }

            @Override
            public void onFailure(Call<ResponseFarms> call, Throwable t) {
//                Log.d("responsez fail",""+t);
                Toast.makeText(getApplicationContext(), "Gagal terkoneksi ke api", Toast.LENGTH_LONG).show();
                pd.hide();

            }


        });

    }
}

